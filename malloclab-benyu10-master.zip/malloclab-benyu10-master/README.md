# malloclab
Carefully read malloclab.pdf in its entirety.
